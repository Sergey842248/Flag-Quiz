# Flag-Quiz
An App to gues countries and capitals. You're also able to see all Countries in a list.

Credits: All apps were created with "WebIntoApp" to convert them from HTML to an actual App.

How to use:
1. Go to your Android-Phone and download the .apk file (EN=Englisch; DE=German) from the "Releases"-section.
2. Open the file (may you have to allow installing from unknown Sources) and click "Install".
3. Open the App

Issues:
If you are facing any Issues or have any idea/suggestions please provide them in the Issues section.

Feel free to mod the app.

Thanks for your support.
